from pathlib import Path


def parse_tle_file(file_path):
    lines = Path(file_path).read_text().splitlines()
    records = []
    for index in range(0, len(lines), 3):
        if index + 2 < len(lines):
            records.append({
                'name': lines[index].strip(),
                'line1': lines[index + 1].strip(),
                'line2': lines[index + 2].strip(),
            })
    return records
