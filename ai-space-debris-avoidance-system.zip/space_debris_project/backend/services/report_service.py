import csv
from io import StringIO


def build_alert_csv(alert_rows):
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow(['alert_id', 'severity', 'collision_probability', 'ai_confidence', 'recommendation'])
    for row in alert_rows:
        writer.writerow([row.id, row.severity, row.collision_probability, row.ai_confidence, row.recommendation])
    return output.getvalue()
