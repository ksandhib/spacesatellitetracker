from datetime import datetime, timedelta
from sgp4.api import Satrec, jday
import math


def propagate_tle(tle_line1, tle_line2, minutes_ahead=0):
    satellite = Satrec.twoline2rv(tle_line1, tle_line2)
    dt = datetime.utcnow() + timedelta(minutes=minutes_ahead)
    jd, fr = jday(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second)
    error_code, position, velocity = satellite.sgp4(jd, fr)

    if error_code != 0:
        raise ValueError(f'SGP4 propagation failed with code {error_code}')

    altitude = math.sqrt(sum(coord ** 2 for coord in position)) - 6378.137
    speed = math.sqrt(sum(component ** 2 for component in velocity))

    return {
        'timestamp': dt.isoformat(),
        'x': position[0], 'y': position[1], 'z': position[2],
        'vx': velocity[0], 'vy': velocity[1], 'vz': velocity[2],
        'altitude_km': altitude,
        'velocity_kms': speed
    }


def future_track(tle_line1, tle_line2, steps=12, interval_minutes=10):
    return [propagate_tle(tle_line1, tle_line2, minutes_ahead=i * interval_minutes) for i in range(steps)]
