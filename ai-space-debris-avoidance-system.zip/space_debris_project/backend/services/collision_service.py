import math

RISK_BANDS = {
    'Low': 50,
    'Medium': 20,
    'High': 10,
    'Critical': 5,
}


def calculate_distance_km(obj_a, obj_b):
    return math.sqrt(
        (obj_a['x'] - obj_b['x']) ** 2 +
        (obj_a['y'] - obj_b['y']) ** 2 +
        (obj_a['z'] - obj_b['z']) ** 2
    )


def classify_risk(distance_km):
    if distance_km <= RISK_BANDS['Critical']:
        return 'Critical'
    if distance_km <= RISK_BANDS['High']:
        return 'High'
    if distance_km <= RISK_BANDS['Medium']:
        return 'Medium'
    return 'Low'


def collision_probability(distance_km):
    return round(max(0.0, min(100.0, 100 - (distance_km * 1.5))), 2)


def recommended_action(risk_level):
    mapping = {
        'Critical': 'Immediate altitude raise by 1.5-2.0 km with micro-thruster burn.',
        'High': 'Short-timing orbital phase shift using controlled micro-thruster adjustment.',
        'Medium': 'Continue monitoring and prepare contingency maneuver window.',
        'Low': 'No maneuver required. Maintain telemetry watch.'
    }
    return mapping[risk_level]
