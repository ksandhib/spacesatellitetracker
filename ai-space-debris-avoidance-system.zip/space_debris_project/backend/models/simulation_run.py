from datetime import datetime
from . import db

class SimulationRun(db.Model):
    __tablename__ = 'simulation_runs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    scenario_name = db.Column(db.String(120), nullable=False)
    outcome = db.Column(db.String(120))
    summary = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
