from datetime import datetime
from . import db

class Alert(db.Model):
    __tablename__ = 'alerts'

    id = db.Column(db.Integer, primary_key=True)
    satellite_id = db.Column(db.Integer, db.ForeignKey('satellites.id'), nullable=False)
    debris_id = db.Column(db.Integer, db.ForeignKey('debris.id'), nullable=False)
    severity = db.Column(db.String(20), nullable=False)
    collision_probability = db.Column(db.Float)
    ai_confidence = db.Column(db.Float)
    recommendation = db.Column(db.Text)
    event_time = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
