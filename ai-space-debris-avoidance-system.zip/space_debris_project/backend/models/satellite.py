from datetime import datetime
from . import db

class Satellite(db.Model):
    __tablename__ = 'satellites'

    id = db.Column(db.Integer, primary_key=True)
    norad_id = db.Column(db.String(30), unique=True, nullable=False)
    name = db.Column(db.String(150), nullable=False)
    tle_line1 = db.Column(db.Text, nullable=False)
    tle_line2 = db.Column(db.Text, nullable=False)
    altitude_km = db.Column(db.Float)
    velocity_kms = db.Column(db.Float)
    inclination_deg = db.Column(db.Float)
    risk_score = db.Column(db.Float, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
