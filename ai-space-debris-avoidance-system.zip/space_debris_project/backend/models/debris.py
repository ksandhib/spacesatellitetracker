from datetime import datetime
from . import db

class Debris(db.Model):
    __tablename__ = 'debris'

    id = db.Column(db.Integer, primary_key=True)
    norad_id = db.Column(db.String(30), unique=True, nullable=False)
    name = db.Column(db.String(150), nullable=False)
    tle_line1 = db.Column(db.Text, nullable=False)
    tle_line2 = db.Column(db.Text, nullable=False)
    object_type = db.Column(db.String(80))
    threat_level = db.Column(db.String(30), default='Low')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
