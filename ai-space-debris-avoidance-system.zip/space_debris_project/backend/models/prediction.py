from datetime import datetime
from . import db

class Prediction(db.Model):
    __tablename__ = 'predictions'

    id = db.Column(db.Integer, primary_key=True)
    satellite_id = db.Column(db.Integer, db.ForeignKey('satellites.id'), nullable=False)
    debris_id = db.Column(db.Integer, db.ForeignKey('debris.id'), nullable=False)
    predicted_distance_km = db.Column(db.Float)
    collision_probability = db.Column(db.Float)
    confidence_score = db.Column(db.Float)
    predicted_at = db.Column(db.DateTime, default=datetime.utcnow)
