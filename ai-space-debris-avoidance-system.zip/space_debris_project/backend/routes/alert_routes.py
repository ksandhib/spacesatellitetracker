from flask import Blueprint, jsonify, Response
from flask_jwt_extended import jwt_required
from models.alert import Alert
from services.report_service import build_alert_csv

alert_bp = Blueprint('alerts', __name__)

@alert_bp.route('/', methods=['GET'])
@jwt_required()
def get_alerts():
    alerts = Alert.query.order_by(Alert.created_at.desc()).all()
    return jsonify([
        {
            'id': row.id,
            'severity': row.severity,
            'collision_probability': row.collision_probability,
            'ai_confidence': row.ai_confidence,
            'recommendation': row.recommendation,
            'event_time': row.event_time.isoformat() if row.event_time else None
        }
        for row in alerts
    ])

@alert_bp.route('/export/csv', methods=['GET'])
@jwt_required()
def export_alerts_csv():
    alerts = Alert.query.order_by(Alert.created_at.desc()).all()
    csv_data = build_alert_csv(alerts)
    return Response(csv_data, mimetype='text/csv', headers={'Content-Disposition': 'attachment; filename=alerts_report.csv'})
