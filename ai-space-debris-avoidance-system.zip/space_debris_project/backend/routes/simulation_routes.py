from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db
from models.simulation_run import SimulationRun

simulation_bp = Blueprint('simulation', __name__)

@simulation_bp.route('/run', methods=['POST'])
@jwt_required()
def run_simulation():
    payload = request.get_json() or {}
    simulation = SimulationRun(
        user_id=int(get_jwt_identity()),
        scenario_name=payload.get('scenario_name', 'Default Maneuver Scenario'),
        outcome='Safe path found',
        summary='AI-recommended altitude raise avoided projected conjunction.'
    )
    db.session.add(simulation)
    db.session.commit()
    return jsonify({'message': 'Simulation completed', 'simulation_id': simulation.id})
