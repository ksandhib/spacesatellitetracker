from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required
from models.debris import Debris

debris_bp = Blueprint('debris', __name__)

@debris_bp.route('/', methods=['GET'])
@jwt_required()
def get_debris_objects():
    rows = Debris.query.all()
    return jsonify([
        {
            'id': row.id,
            'norad_id': row.norad_id,
            'name': row.name,
            'object_type': row.object_type,
            'threat_level': row.threat_level
        }
        for row in rows
    ])
