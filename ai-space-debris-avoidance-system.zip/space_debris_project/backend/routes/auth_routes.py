from flask import Blueprint, request, jsonify
from models import db
from models.user import User
from utils.auth import generate_token

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    payload = request.get_json() or {}
    if User.query.filter_by(email=payload.get('email')).first():
        return jsonify({'message': 'Email already exists'}), 409

    user = User(name=payload['name'], email=payload['email'])
    user.set_password(payload['password'])
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully'}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    payload = request.get_json() or {}
    user = User.query.filter_by(email=payload.get('email')).first()

    if not user or not user.check_password(payload.get('password', '')):
        return jsonify({'message': 'Invalid credentials'}), 401

    token = generate_token(user)
    return jsonify({
        'token': token,
        'user': { 'id': user.id, 'name': user.name, 'email': user.email, 'role': user.role }
    })
