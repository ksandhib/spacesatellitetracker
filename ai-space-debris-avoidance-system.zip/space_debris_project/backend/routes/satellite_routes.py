from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required
from models.satellite import Satellite
from services.tle_service import future_track, propagate_tle

satellite_bp = Blueprint('satellites', __name__)

@satellite_bp.route('/', methods=['GET'])
@jwt_required()
def get_satellites():
    satellites = Satellite.query.all()
    return jsonify([
        {
            'id': sat.id,
            'norad_id': sat.norad_id,
            'name': sat.name,
            'altitude_km': sat.altitude_km,
            'velocity_kms': sat.velocity_kms,
            'inclination_deg': sat.inclination_deg,
            'risk_score': sat.risk_score
        } for sat in satellites
    ])

@satellite_bp.route('/<int:satellite_id>/track', methods=['GET'])
@jwt_required()
def get_satellite_track(satellite_id):
    sat = Satellite.query.get_or_404(satellite_id)
    return jsonify(future_track(sat.tle_line1, sat.tle_line2))

@satellite_bp.route('/<int:satellite_id>/live', methods=['GET'])
@jwt_required()
def get_satellite_live(satellite_id):
    sat = Satellite.query.get_or_404(satellite_id)
    return jsonify(propagate_tle(sat.tle_line1, sat.tle_line2))
