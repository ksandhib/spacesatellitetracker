from flask import Flask, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from config.settings import Config
from models import db
import models.all_models
from routes.auth_routes import auth_bp
from routes.satellite_routes import satellite_bp
from routes.debris_routes import debris_bp
from routes.prediction_routes import prediction_bp
from routes.alert_routes import alert_bp
from routes.simulation_routes import simulation_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    CORS(app)
    db.init_app(app)
    JWTManager(app)

    @app.route('/api/health')
    def health():
        return jsonify({'status': 'ok', 'service': 'space-debris-backend'})

    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(satellite_bp, url_prefix='/api/satellites')
    app.register_blueprint(debris_bp, url_prefix='/api/debris')
    app.register_blueprint(prediction_bp, url_prefix='/api/predictions')
    app.register_blueprint(alert_bp, url_prefix='/api/alerts')
    app.register_blueprint(simulation_bp, url_prefix='/api/simulation')

    return app


app = create_app()

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)
