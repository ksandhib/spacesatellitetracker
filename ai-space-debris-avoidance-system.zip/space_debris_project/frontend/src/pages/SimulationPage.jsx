import PageShell from '../components/common/PageShell';

export default function SimulationPage() {
  return (
    <PageShell title="Simulation">
      <div className="glass info-card">
        <h3>Scenario Testing Console</h3>
        <p>Use this screen for play, pause, reset, time-step control, and safe-path comparison.</p>
        <div className="button-group">
          <button className="primary-btn">Play</button>
          <button className="secondary-btn">Pause</button>
          <button className="secondary-btn">Reset</button>
        </div>
        <input type="range" min="0" max="100" defaultValue="35" />
      </div>
    </PageShell>
  );
}
