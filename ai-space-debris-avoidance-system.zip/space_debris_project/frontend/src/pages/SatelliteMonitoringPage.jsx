import PageShell from '../components/common/PageShell';

const satellites = [
  { id: 'SAT-1001', name: 'Astra Relay', velocity: '7.67 km/s', altitude: '590 km', inclination: '96.7°', risk: 'Low' },
  { id: 'SAT-1002', name: 'Luna Watch', velocity: '7.54 km/s', altitude: '710 km', inclination: '99.1°', risk: 'Medium' },
  { id: 'SAT-1003', name: 'Earth Link', velocity: '7.71 km/s', altitude: '540 km', inclination: '87.3°', risk: 'High' }
];

export default function SatelliteMonitoringPage() {
  return (
    <PageShell title="Satellite Monitoring">
      <div className="glass list-page">
        <div className="toolbar">
          <input placeholder="Search satellite name or NORAD ID" />
          <select><option>All Risk Levels</option><option>Low</option><option>Medium</option><option>High</option></select>
        </div>
        <div className="cards-grid">
          {satellites.map((sat) => (
            <div key={sat.id} className="glass info-card">
              <h3>{sat.name}</h3>
              <p>{sat.id}</p>
              <div className="detail-stack compact">
                <div><span>Velocity</span><strong>{sat.velocity}</strong></div>
                <div><span>Altitude</span><strong>{sat.altitude}</strong></div>
                <div><span>Inclination</span><strong>{sat.inclination}</strong></div>
                <div><span>Risk Score</span><strong>{sat.risk}</strong></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </PageShell>
  );
}
