import PageShell from '../components/common/PageShell';

export default function CollisionPredictionPage() {
  const rows = [
    ['Orbital Relay Prime', 'COSMOS-2251 FRAGMENT', '82%', '2h 11m', '94.7%', 'Raise altitude'],
    ['Astra Relay', 'IRIDIUM 33 DEB', '46%', '9h 44m', '87.2%', 'Micro-thruster correction']
  ];

  return (
    <PageShell title="Collision Prediction">
      <div className="glass table-card">
        <h3>Future Position Risk Assessment</h3>
        <table>
          <thead>
            <tr>
              <th>Satellite</th>
              <th>Threat Object</th>
              <th>Collision Probability</th>
              <th>Time to Impact</th>
              <th>AI Confidence</th>
              <th>Recommended Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={index}>{row.map((cell, cellIndex) => <td key={cellIndex}>{cell}</td>)}</tr>
            ))}
          </tbody>
        </table>
      </div>
    </PageShell>
  );
}
