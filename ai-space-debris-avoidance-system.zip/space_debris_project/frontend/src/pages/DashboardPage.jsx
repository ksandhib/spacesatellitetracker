import PageShell from '../components/common/PageShell';
import MetricCard from '../components/dashboard/MetricCard';
import EarthScene from '../components/dashboard/EarthScene';
import RiskChart from '../components/dashboard/RiskChart';
import DebrisDistributionChart from '../components/dashboard/DebrisDistributionChart';
import AlertsTable from '../components/dashboard/AlertsTable';

export default function DashboardPage() {
  return (
    <PageShell>
      <section className="metrics-grid">
        <MetricCard title="Tracked Debris" value="12,481" subtext="+2.1% vs yesterday" />
        <MetricCard title="Active Satellites" value="641" subtext="Across 6 monitored constellations" />
        <MetricCard title="High-Risk Objects" value="18" subtext="Within prediction threshold" />
        <MetricCard title="System Health" value="99.92%" subtext="AI model and telemetry nominal" />
      </section>

      <section className="dashboard-grid">
        <div className="glass side-panel">
          <h3>Selected Satellite</h3>
          <div className="detail-stack">
            <div><span>ID</span><strong>SAT-AX 4421</strong></div>
            <div><span>Name</span><strong>Orbital Relay Prime</strong></div>
            <div><span>Velocity</span><strong>7.66 km/s</strong></div>
            <div><span>Altitude</span><strong>612 km</strong></div>
            <div><span>Inclination</span><strong>97.4°</strong></div>
            <div><span>Fuel</span><strong>72%</strong></div>
            <div><span>Risk</span><strong className="text-danger">High</strong></div>
          </div>
          <div className="button-group">
            <button className="primary-btn">Simulate</button>
            <button className="secondary-btn">Predict</button>
            <button className="secondary-btn">Reset</button>
            <button className="secondary-btn">Export</button>
          </div>
        </div>

        <EarthScene />

        <div className="glass side-panel">
          <h3>AI Intelligence</h3>
          <div className="alert-card critical">
            <span>Collision Alert</span>
            <strong>Critical proximity window in 2h 11m</strong>
          </div>
          <div className="detail-stack">
            <div><span>Risk Meter</span><strong>91 / 100</strong></div>
            <div><span>AI Confidence</span><strong>94.7%</strong></div>
            <div><span>Recommended Action</span><strong>Raise altitude by 1.8 km</strong></div>
            <div><span>Timing Window</span><strong>T+01:34:00</strong></div>
            <div><span>Priority</span><strong className="text-danger">Immediate</strong></div>
          </div>
          <div className="glass explanation-box">
            <h4>Why AI flagged this</h4>
            <p>Model detected converging orbital vectors, shrinking minimum separation, and repeated anomaly spikes across 4 future time steps.</p>
          </div>
        </div>
      </section>

      <section className="bottom-grid">
        <RiskChart />
        <DebrisDistributionChart />
      </section>

      <section className="bottom-grid single">
        <AlertsTable />
      </section>
    </PageShell>
  );
}
