import PageShell from '../components/common/PageShell';

const debris = [
  { name: 'COSMOS Fragment', size: '0.8 m', threat: 'Critical', orbit: 'LEO Cluster A' },
  { name: 'Fengyun Debris', size: '0.3 m', threat: 'High', orbit: 'Sun-synchronous band' },
  { name: 'Mission Adapter', size: '1.1 m', threat: 'Medium', orbit: 'LEO Cluster B' }
];

export default function DebrisTrackingPage() {
  return (
    <PageShell title="Debris Tracking">
      <div className="cards-grid">
        {debris.map((item) => (
          <div className="glass info-card" key={item.name}>
            <h3>{item.name}</h3>
            <div className="detail-stack compact">
              <div><span>Estimated Size</span><strong>{item.size}</strong></div>
              <div><span>Threat Level</span><strong>{item.threat}</strong></div>
              <div><span>Cluster</span><strong>{item.orbit}</strong></div>
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  );
}
