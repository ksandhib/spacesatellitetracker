import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../services/api';
import { loginUser } from '../hooks/useAuth';

export default function LoginPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    try {
      const { data } = await api.post('/auth/login', form);
      loginUser(data.token, data.user);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to sign in.');
    }
  };

  return (
    <div className="auth-page">
      <form className="glass auth-card" onSubmit={handleSubmit}>
        <p className="eyebrow">Mission Control Access</p>
        <h1>Secure Sign In</h1>
        <input type="email" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
        <input type="password" placeholder="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
        {error && <p className="error-text">{error}</p>}
        <button type="submit" className="primary-btn">Enter Command Center</button>
        <p className="muted">Need an account? <Link to="/register">Register</Link></p>
      </form>
    </div>
  );
}
