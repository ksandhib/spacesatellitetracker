import PageShell from '../components/common/PageShell';

export default function AlertsReportsPage() {
  return (
    <PageShell title="Alerts & Reports">
      <div className="cards-grid">
        <div className="glass info-card">
          <h3>Risk Summary</h3>
          <p>18 high-risk objects detected in the next 24 hours.</p>
          <button className="primary-btn">Download PDF Report</button>
        </div>
        <div className="glass info-card">
          <h3>Alert History</h3>
          <p>Sort, filter, and review all previous event logs.</p>
          <button className="secondary-btn">Download CSV</button>
        </div>
      </div>
    </PageShell>
  );
}
