import Navbar from '../layout/Navbar';
import Sidebar from '../layout/Sidebar';

export default function PageShell({ title, children }) {
  return (
    <div className="app-shell">
      <Sidebar />
      <main className="main-layout">
        <Navbar />
        {title && <div className="page-title"><h2>{title}</h2></div>}
        {children}
      </main>
    </div>
  );
}
