import { Activity, BellRing, UserCircle2 } from 'lucide-react';

export default function Navbar() {
  const user = JSON.parse(localStorage.getItem('space_user') || '{}');

  return (
    <header className="glass navbar">
      <div>
        <p className="eyebrow">Orbital Intelligence Suite</p>
        <h1>AI Space Debris Avoidance System</h1>
      </div>
      <div className="status-pill">
        <Activity size={16} />
        <span>Live Sync · Nominal</span>
      </div>
      <div className="nav-profile">
        <BellRing size={18} />
        <UserCircle2 size={26} />
        <span>{user.name || 'Mission Admin'}</span>
      </div>
    </header>
  );
}
