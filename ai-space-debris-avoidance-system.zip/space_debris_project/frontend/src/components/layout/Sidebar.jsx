import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Satellite, Radar, ShieldAlert, FileWarning, PlayCircle } from 'lucide-react';

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/satellites', label: 'Satellites', icon: Satellite },
  { to: '/debris', label: 'Debris', icon: Radar },
  { to: '/predictions', label: 'Predictions', icon: ShieldAlert },
  { to: '/alerts', label: 'Alerts & Reports', icon: FileWarning },
  { to: '/simulation', label: 'Simulation', icon: PlayCircle }
];

export default function Sidebar() {
  return (
    <aside className="glass sidebar">
      {navItems.map(({ to, label, icon: Icon }) => (
        <NavLink key={to} to={to} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <Icon size={18} />
          <span>{label}</span>
        </NavLink>
      ))}
    </aside>
  );
}
