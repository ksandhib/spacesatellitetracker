import { AreaChart, Area, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

const data = [
  { t: '00:00', risk: 22 },
  { t: '04:00', risk: 28 },
  { t: '08:00', risk: 34 },
  { t: '12:00', risk: 53 },
  { t: '16:00', risk: 41 },
  { t: '20:00', risk: 30 }
];

export default function RiskChart() {
  return (
    <div className="glass chart-card">
      <h3>Risk Over Time</h3>
      <ResponsiveContainer width="100%" height={240}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
          <XAxis dataKey="t" stroke="#9fb4d1" />
          <YAxis stroke="#9fb4d1" />
          <Tooltip />
          <Area type="monotone" dataKey="risk" stroke="#4de2ff" fill="rgba(77,226,255,0.25)" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
