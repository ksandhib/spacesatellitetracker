import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const data = [
  { name: 'Fragments', value: 45, color: '#6ef2ff' },
  { name: 'Spent Stages', value: 22, color: '#8b6bff' },
  { name: 'Defunct Satellites', value: 18, color: '#2ee6a6' },
  { name: 'Mission Related', value: 15, color: '#ff7bd5' }
];

export default function DebrisDistributionChart() {
  return (
    <div className="glass chart-card">
      <h3>Debris Type Distribution</h3>
      <ResponsiveContainer width="100%" height={240}>
        <PieChart>
          <Pie data={data} dataKey="value" outerRadius={90} label>
            {data.map((entry) => <Cell key={entry.name} fill={entry.color} />)}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
