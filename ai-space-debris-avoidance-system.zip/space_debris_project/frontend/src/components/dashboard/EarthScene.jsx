import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import * as THREE from 'three';

function Earth() {
  return (
    <mesh>
      <sphereGeometry args={[1.2, 64, 64]} />
      <meshStandardMaterial color="#1a6cff" emissive="#1636ff" emissiveIntensity={0.4} roughness={0.7} />
    </mesh>
  );
}

function OrbitRing({ radius }) {
  const curve = new THREE.EllipseCurve(0, 0, radius, radius, 0, 2 * Math.PI, false, 0);
  const points = curve.getPoints(100).map((p) => new THREE.Vector3(p.x, p.y, 0));
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  return (
    <line geometry={geometry} rotation={[Math.PI / 2, 0, 0]}>
      <lineBasicMaterial color="#58e7ff" transparent opacity={0.4} />
    </line>
  );
}

function Marker({ position, color = '#ff5ef2' }) {
  return (
    <mesh position={position}>
      <sphereGeometry args={[0.04, 24, 24]} />
      <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} />
    </mesh>
  );
}

export default function EarthScene() {
  return (
    <div className="glass earth-card">
      <div className="panel-header">
        <h3>Real-Time Orbital View</h3>
        <span>3D Earth · Satellites · Debris · Risk Zones</span>
      </div>
      <Canvas camera={{ position: [0, 0, 4] }}>
        <ambientLight intensity={1.2} />
        <pointLight position={[3, 3, 3]} intensity={30} />
        <Stars radius={70} depth={50} count={3000} factor={4} saturation={0} fade speed={1} />
        <Earth />
        <OrbitRing radius={1.8} />
        <OrbitRing radius={2.3} />
        <OrbitRing radius={2.8} />
        <Marker position={[2.1, 0.2, 0]} color="#6ef2ff" />
        <Marker position={[-1.7, 0.7, 0.6]} color="#ffaa40" />
        <Marker position={[0.8, 1.6, -0.4]} color="#ff5ef2" />
        <OrbitControls enablePan={false} />
      </Canvas>
    </div>
  );
}
