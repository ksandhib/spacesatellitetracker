export default function MetricCard({ title, value, subtext }) {
  return (
    <div className="glass metric-card">
      <p>{title}</p>
      <h3>{value}</h3>
      <span>{subtext}</span>
    </div>
  );
}
