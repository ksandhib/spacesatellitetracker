const alerts = [
  { id: 'ALT-901', object: 'COSMOS-2251 FRAGMENT', severity: 'Critical', eta: '02h 11m' },
  { id: 'ALT-902', object: 'FENGYUN-1C DEB', severity: 'High', eta: '08h 42m' },
  { id: 'ALT-903', object: 'IRIDIUM 33 DEB', severity: 'Medium', eta: '15h 09m' }
];

export default function AlertsTable() {
  return (
    <div className="glass table-card">
      <h3>Recent Alerts</h3>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Object</th>
            <th>Severity</th>
            <th>ETA</th>
          </tr>
        </thead>
        <tbody>
          {alerts.map((alert) => (
            <tr key={alert.id}>
              <td>{alert.id}</td>
              <td>{alert.object}</td>
              <td><span className={`badge ${alert.severity.toLowerCase()}`}>{alert.severity}</span></td>
              <td>{alert.eta}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
