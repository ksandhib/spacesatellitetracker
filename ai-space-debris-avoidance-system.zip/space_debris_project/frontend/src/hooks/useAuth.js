export const isAuthenticated = () => Boolean(localStorage.getItem('space_token'));

export const loginUser = (token, user) => {
  localStorage.setItem('space_token', token);
  localStorage.setItem('space_user', JSON.stringify(user));
};

export const logoutUser = () => {
  localStorage.removeItem('space_token');
  localStorage.removeItem('space_user');
};
