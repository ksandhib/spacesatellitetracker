import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import SatelliteMonitoringPage from './pages/SatelliteMonitoringPage';
import DebrisTrackingPage from './pages/DebrisTrackingPage';
import CollisionPredictionPage from './pages/CollisionPredictionPage';
import AlertsReportsPage from './pages/AlertsReportsPage';
import SimulationPage from './pages/SimulationPage';
import ProtectedRoute from './components/common/ProtectedRoute';

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        }
      />
      <Route path="/satellites" element={<ProtectedRoute><SatelliteMonitoringPage /></ProtectedRoute>} />
      <Route path="/debris" element={<ProtectedRoute><DebrisTrackingPage /></ProtectedRoute>} />
      <Route path="/predictions" element={<ProtectedRoute><CollisionPredictionPage /></ProtectedRoute>} />
      <Route path="/alerts" element={<ProtectedRoute><AlertsReportsPage /></ProtectedRoute>} />
      <Route path="/simulation" element={<ProtectedRoute><SimulationPage /></ProtectedRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
