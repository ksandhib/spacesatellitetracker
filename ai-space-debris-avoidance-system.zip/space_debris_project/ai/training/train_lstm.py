from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping
import joblib

BASE_DIR = Path(__file__).resolve().parents[1]
MODEL_DIR = BASE_DIR / 'models'
MODEL_DIR.mkdir(exist_ok=True)


def create_demo_dataset(samples=500):
    time = np.arange(samples)
    x = np.sin(time / 12) * 1200 + np.random.normal(0, 10, samples)
    y = np.cos(time / 12) * 1200 + np.random.normal(0, 10, samples)
    z = np.sin(time / 18) * 900 + np.random.normal(0, 10, samples)
    return pd.DataFrame({'x': x, 'y': y, 'z': z})


def build_sequences(data, sequence_length=20):
    X, y = [], []
    for i in range(len(data) - sequence_length):
        X.append(data[i:i + sequence_length])
        y.append(data[i + sequence_length])
    return np.array(X), np.array(y)


def main():
    df = create_demo_dataset()
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(df[['x', 'y', 'z']])

    X, y = build_sequences(scaled)
    split_index = int(len(X) * 0.8)
    X_train, X_test = X[:split_index], X[split_index:]
    y_train, y_test = y[:split_index], y[split_index:]

    model = Sequential([
        LSTM(64, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])),
        Dropout(0.2),
        LSTM(32),
        Dense(32, activation='relu'),
        Dense(3)
    ])

    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    model.fit(
        X_train, y_train,
        validation_data=(X_test, y_test),
        epochs=20,
        batch_size=16,
        callbacks=[EarlyStopping(patience=4, restore_best_weights=True)],
        verbose=1
    )

    model.save(MODEL_DIR / 'orbit_lstm.keras')
    joblib.dump(scaler, MODEL_DIR / 'orbit_scaler.pkl')
    print('Model and scaler saved successfully.')


if __name__ == '__main__':
    main()
