Place generated training sequences or processed orbital feature datasets here.
