from pathlib import Path
import numpy as np
import joblib
from tensorflow.keras.models import load_model

BASE_DIR = Path(__file__).resolve().parents[1]
MODEL_PATH = BASE_DIR / 'models' / 'orbit_lstm.keras'
SCALER_PATH = BASE_DIR / 'models' / 'orbit_scaler.pkl'


def predict_next(sequence_xyz):
    model = load_model(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)

    scaled = scaler.transform(sequence_xyz)
    X = np.expand_dims(scaled, axis=0)
    prediction = model.predict(X, verbose=0)[0]
    return scaler.inverse_transform([prediction])[0].tolist()


if __name__ == '__main__':
    dummy_sequence = np.array([[i, i + 1, i + 2] for i in range(20)], dtype=float)
    print(predict_next(dummy_sequence))
