# Setup Guide

## 1) Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python app.py
```

## 2) Frontend
```bash
cd frontend
npm install
npm run dev
```

## 3) Database
Create a MySQL database named `space_debris_ai`, then execute:
```bash
mysql -u root -p space_debris_ai < ../database/schema.sql
mysql -u root -p space_debris_ai < ../database/seeds/sample_seed.sql
```

## 4) AI Model
```bash
cd ai
pip install -r requirements.txt
python training/train_lstm.py
```
