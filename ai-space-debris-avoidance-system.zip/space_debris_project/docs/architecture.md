# Architecture Flow

1. TLE data is loaded from a public source or local sample file.
2. Backend parses TLE lines and propagates current/future positions using SGP4.
3. AI module trains an LSTM on historical coordinate sequences.
4. Prediction service compares future satellite and debris trajectories.
5. Collision service calculates minimum distance and risk band.
6. Alerts are generated and persisted to MySQL.
7. React dashboard fetches API data and visualizes risk, objects, and recommendations.
8. Simulation module allows what-if maneuver testing and records outcomes.
