INSERT INTO satellites (norad_id, name, tle_line1, tle_line2, altitude_km, velocity_kms, inclination_deg, risk_score) VALUES
('25544', 'ISS (ZARYA)', '1 25544U 98067A   24124.51884259  .00022463  00000+0  39898-3 0  9991', '2 25544  51.6399 210.6066 0004785 158.1122 279.6693 15.49849991452123', 420.0, 7.66, 51.6, 32.0),
('43013', 'Orbital Relay Prime', '1 43013U 17073A   24123.72158032  .00000037  00000+0  27852-4 0  9995', '2 43013  97.4388 177.3408 0013882  77.2371 283.0428 15.20630456353067', 612.0, 7.56, 97.4, 81.0);

INSERT INTO debris (norad_id, name, tle_line1, tle_line2, object_type, threat_level) VALUES
('30671', 'FENGYUN-1C DEB', '1 30671U 99025AA  24124.08623199  .00016350  00000+0  11689-2 0  9996', '2 30671  98.7500 180.1256 0040156 246.9851 112.6930 14.97290548886660', 'Fragment', 'High'),
('33757', 'COSMOS-2251 FRAGMENT', '1 33757U 93036RU  24124.46496678  .00002508  00000+0  56328-3 0  9996', '2 33757  74.0442 258.6936 0041282 282.8026  76.8458 14.49389996810679', 'Fragment', 'Critical');

INSERT INTO alerts (satellite_id, debris_id, severity, collision_probability, ai_confidence, recommendation, event_time) VALUES
(2, 2, 'Critical', 82.0, 94.7, 'Raise altitude by 1.8 km in T+01:34:00 window.', NOW()),
(1, 1, 'High', 61.0, 88.3, 'Prepare micro-thruster phase adjustment.', NOW());

INSERT INTO logs (level, source, message) VALUES
('INFO', 'telemetry-engine', 'Initial orbital telemetry sync completed.'),
('WARN', 'risk-engine', 'One conjunction moved into high-risk band.');
