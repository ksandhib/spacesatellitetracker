CREATE TABLE IF NOT EXISTS users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'operator',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS satellites (
  id INT PRIMARY KEY AUTO_INCREMENT,
  norad_id VARCHAR(30) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  tle_line1 TEXT NOT NULL,
  tle_line2 TEXT NOT NULL,
  altitude_km FLOAT,
  velocity_kms FLOAT,
  inclination_deg FLOAT,
  risk_score FLOAT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS debris (
  id INT PRIMARY KEY AUTO_INCREMENT,
  norad_id VARCHAR(30) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  tle_line1 TEXT NOT NULL,
  tle_line2 TEXT NOT NULL,
  object_type VARCHAR(80),
  threat_level VARCHAR(30) DEFAULT 'Low',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS alerts (
  id INT PRIMARY KEY AUTO_INCREMENT,
  satellite_id INT NOT NULL,
  debris_id INT NOT NULL,
  severity VARCHAR(20) NOT NULL,
  collision_probability FLOAT,
  ai_confidence FLOAT,
  recommendation TEXT,
  event_time DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_alert_sat FOREIGN KEY (satellite_id) REFERENCES satellites(id),
  CONSTRAINT fk_alert_debris FOREIGN KEY (debris_id) REFERENCES debris(id)
);

CREATE TABLE IF NOT EXISTS predictions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  satellite_id INT NOT NULL,
  debris_id INT NOT NULL,
  predicted_distance_km FLOAT,
  collision_probability FLOAT,
  confidence_score FLOAT,
  predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pred_sat FOREIGN KEY (satellite_id) REFERENCES satellites(id),
  CONSTRAINT fk_pred_debris FOREIGN KEY (debris_id) REFERENCES debris(id)
);

CREATE TABLE IF NOT EXISTS logs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  level VARCHAR(20) NOT NULL,
  source VARCHAR(120) NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS simulation_runs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  scenario_name VARCHAR(120) NOT NULL,
  outcome VARCHAR(120),
  summary TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sim_user FOREIGN KEY (user_id) REFERENCES users(id)
);
