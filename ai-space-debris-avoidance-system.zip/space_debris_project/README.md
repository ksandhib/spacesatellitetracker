# AI-Based Space Debris Avoidance System

A premium full-stack mission-control web application for monitoring satellites and debris, predicting collision risk with AI, simulating avoidance maneuvers, and visualizing orbital activity around Earth.

## Stack
- Frontend: React + Vite + CSS + Recharts + Three.js + React Three Fiber
- Backend: Flask + Flask-CORS + SQLAlchemy + JWT
- Database: MySQL
- AI: TensorFlow/Keras LSTM
- Orbital Propagation: SGP4 using TLE data

## Quick Start
See `docs/setup.md`.
